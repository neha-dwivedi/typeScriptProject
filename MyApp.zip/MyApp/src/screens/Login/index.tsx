/* eslint-disable prettier/prettier */
import React, {Component} from 'react';
import {
  View,
  Keyboard,
  SafeAreaView,
  Alert,
  TouchableOpacity,
  TextInput,
  Image,
  Text,
} from 'react-native';
import {images, strings} from '../../themes';
import {homestyle} from '../../styles/';
import {Actions} from 'react-native-router-flux';

import {connect} from 'react-redux';

import {fetchLoginAccounts} from '../../redux/actions/Login';

import {apiCall, netStatus} from '../../config/ApiManager';
import {METHOD, END_POINT} from '../../config/ApiConfig';
import GlobalValidations from '../../utils/GlobalValidation';

interface Props {}

interface State {
  emailid: any;
  isValidUser: boolean
}

class Login extends Component {
  state = {
    emailid: 'Sincere@april.biz',
    isValidUser: false,
  };

  checkValidation = () => {
    const {emailid } = this.state;
    if (GlobalValidations.isEmailInvalid(emailid)) {
      Alert.alert(strings.VALIDATE_EMAIL_INVALID);
      return false;
    }
    // else if (GlobalValidations.isFieldEmpty(password)) {
    //   Alert.alert(strings.VALIDATE_PASSWORD_REQUIRED);
    //   return false;
    // }
    else {
      this.loginpress();
    }
    return true;
  };

  loginpress = async () => {
    Keyboard.dismiss();
    const {emailid, isValidUser} = this.state;
    netStatus((isConnected: any) => {
      if (isConnected) {
        apiCall(
          END_POINT.LOGIN,
          METHOD.GET,
          ' ',
          (result:any) => {
            this.props.fetchLoginAccounts(result);
            for (let index = 0; index < result.length; index++) {
              if (emailid === result[index].email)
              {
                this.setState({
                  isValidUser: true,
                });
              }
            }
            if (isValidUser){
              Alert.alert('Login successfully');
              this.setState({
                isValidUser: false,
              });
              Actions.Home();
            }
            else {
              Alert.alert('User not exist');
            }
          },
          (_error: any) => {
            Alert.alert(strings.SOMTHING_WENT_WRONG);
          },
        );

      } else {
        Alert.alert(strings.NETWORK_ERROR);
      }
    });
  };

  render() {
    const {emailid} = this.state;
    return (
      <SafeAreaView style={homestyle.safeareabox}>
        <View style={homestyle.screenbackground}>
          <View style={homestyle.logocontener}>
            <Image
              source={images.Oakwoodlogo}
              style={homestyle.homescreenlogo}
            />
          </View>
          <View style={homestyle.timedatecontener}>
            <TextInput
              style={homestyle.inputBoxStyling}
              underlineColorAndroid="transparent"
              placeholder="Email"
              value={emailid}
              placeholderTextColor="#29363F"
              onChangeText={(text) => {
                this.setState({emailid: text});
              }}
            />
            {/* <TextInput
              style={homestyle.inputBoxStyling}
              secureTextEntry={true}
              value={password}
              underlineColorAndroid="transparent"
              placeholder="Password"
              placeholderTextColor="#29363F"
              onChangeText={(text) => {
                this.setState({password: text});
              }}
            /> */}
          </View>
          <View style={homestyle.startbuttoncontener}>
            <TouchableOpacity
              style={homestyle.startbutton}
              onPress={() => {
                this.checkValidation();
              }}>
              <Text style={homestyle.startbuttontext}>Login</Text>
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    );
  }
}

const mapStateToProps = (state:any) => {
  return {
      login: state.login.login,
  };
};

const mapDispatchToProps = (dispatchEvent:any) => {
  return {
    fetchLoginAccounts: (userinfo:any) => dispatchEvent(fetchLoginAccounts(userinfo)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Login);

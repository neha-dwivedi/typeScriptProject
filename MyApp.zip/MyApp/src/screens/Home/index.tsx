/* eslint-disable react-native/no-inline-styles */
/* eslint-disable prettier/prettier */
import React, {Component} from 'react';
import {
  View,
  SafeAreaView,
  Alert,FlatList,
  TouchableOpacity,
  Modal,
  Text,
} from 'react-native';
import { strings} from '../../themes';
import {homestyle} from '../../styles/';

import {connect} from 'react-redux';
import {fetchUserDetails, fetchUserComments} from '../../redux/actions/Home';
import {apiCall, netStatus} from '../../config/ApiManager';
import {METHOD, END_POINT} from '../../config/ApiConfig';

interface Props {}

interface State {
  userList : any[];
  modalVisible: boolean;
  userCommentTitle:any;
  userCommentBody:any;
}

interface linkingToObject {
  fetchUserDetails : ([]) => void;
  fetchUserComments : ([]) => void;
}

 class Home extends Component {

  state = {
    userList:[],
    modalVisible:false,
    userCommentTitle:'',
    userCommentBody:'',
  }

  componentDidMount = () => {
    netStatus((isConnected: any) => {
      if (isConnected) {
        apiCall(
          END_POINT.HOME_CATEGORY_LIST,
          METHOD.GET,
          ' ',
          (result:any) => {
            this.props.fetchUserDetails(result);
            this.setState({
              userList: result,
            });
          },
          (_error: any) => {
            Alert.alert(strings.SOMTHING_WENT_WRONG);
          },
        );
      } else {
        Alert.alert(strings.NETWORK_ERROR);
      }
    });
  };

  commentAPICall(id:any){
    netStatus((isConnected: any) => {
      if (isConnected) {
        apiCall(
          END_POINT.HOME_COMMENT_DETAIL,
          METHOD.GET,
          ' ',
          (result:any) => {
            this.props.fetchUserComments(result);
            for (let index = 0; index < result.length; index++) {
              if (id === result[index].id)
              {
                this.setState({
                  userCommentTitle: result[index].name,
                  userCommentBody:result[index].body
                });
              }
            }
            this.setState({
              userList: result,
            });
          },
          (_error: any) => {
            Alert.alert(strings.SOMTHING_WENT_WRONG);
          },
        );
      } else {
        Alert.alert(strings.NETWORK_ERROR);
      }
    });
    this.setState({modalVisible:true});
  }

  renderToUserList(userData:any){
    return (
      <TouchableOpacity onPress={()=>this.commentAPICall(userData.item.id)}>
      <View style={{flexDirection:'column',
      shadowOffset: {width: 0, height: 0},
      shadowOpacity: 1,
      shadowRadius: 8,backgroundColor:'white',
      elevation: 8, borderRadius:10, borderWidth:1, margin:10, padding:10}}>
       <Text style={{fontSize:20}}>{'Title: '}</Text>
       <Text>{userData.item.title}</Text>
       <Text style={{fontSize:20}}>{'Desc: '}</Text>
       <Text>{userData.item.body}</Text>
      </View>
     </TouchableOpacity>
    );
  }

  render() {
    const {userList,userCommentTitle,userCommentBody,modalVisible} = this.state;
    return (
      <SafeAreaView style={homestyle.safeareabox}>
        <View style={homestyle.screenbackground}>
          <Text style={{fontSize:30,margin:20,fontWeight:'bold', textAlign:'center'}}>{'User List'}</Text>
        <FlatList
                    style={{width: '100%'}}
                    data={userList}
                    extraData={this.state}
                    renderItem={(item) => this.renderToUserList(item)}
                    keyExtractor={(item, index) => index.toString()}
                  />
        </View>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          this.setState({modalVisible:false})
        }}
      >
        <View style={homestyle.centeredView}>
          <View style={homestyle.modalView}>
            <Text style={homestyle.modalText}>{userCommentTitle}</Text>
            <Text style={homestyle.modalText}>{userCommentBody}</Text>
            <TouchableOpacity onPress={()=>{this.setState({modalVisible:false})}}
              style={{ ...homestyle.openButton, backgroundColor: '#2196F3' }}

            >
              <Text style={homestyle.textStyle}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      </SafeAreaView>
    );
  }
}

const mapStateToProps = (state:any) => {
  return {
      home: state.home.home,
      comments: state.comments.comments,
  };
};

const mapDispatchToProps = (dispatchEvent:any) => {
  return {
    fetchUserDetails: (userinfo:any) => dispatchEvent(fetchUserDetails(userinfo)),
    fetchUserComments: (userinfo:any) => dispatchEvent(fetchUserComments(userinfo)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Home);

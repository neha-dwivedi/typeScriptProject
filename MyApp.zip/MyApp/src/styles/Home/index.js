import {StyleSheet} from 'react-native';
import {colors, fonts} from '../../themes';
import {moderateScale} from '../../themes/styleConfig';

export const homestyle = StyleSheet.create({
  safeareabox: {
    flex: 1,
  },
  screenbackground: {
    flex: 1,
    backgroundColor: colors.whitetext,
  },
  logocontener: {
    flex: 1,
    top: moderateScale(20),
    // justifyContent:'center',
    alignItems: 'center',
  },
  inputBoxStyling: {
    borderWidth: 1,
    width: moderateScale(300),
    padding: moderateScale(15),
    height: moderateScale(50),
    borderRadius: moderateScale(10),
    color: '#29363F',
    marginBottom: 23,
  },
  timedatecontener: {
    flex: 0.8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  startbuttoncontener: {
    flex: 0.5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  servicescontener: {
    flex: 0.7,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  homescreenlogo: {
    marginTop: moderateScale(21),
    height: moderateScale(153),
    width: moderateScale(153),
  },
  startbutton: {
    justifyContent: 'center',
    alignItems: 'center',
    width: moderateScale(300),
    height: moderateScale(46),
    borderRadius: moderateScale(20),
    backgroundColor: colors.bluebackground,
    // box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
  },
  startbuttontext: {
    fontFamily: fonts.SweetSPRegular,
    fontStyle: 'normal',
    fontWeight: '500',
    fontSize: moderateScale(12),
    letterSpacing: moderateScale(0.3),
    color: colors.whitetext,
  },
  servicesbuttoncontener: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignItems: 'center',
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  openButton: {
    backgroundColor: '#F194FF',
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
});

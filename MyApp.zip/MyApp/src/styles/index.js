import {homestyle} from './Home';

export { homestyle }
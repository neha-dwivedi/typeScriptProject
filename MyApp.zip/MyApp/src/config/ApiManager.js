import NetInfo from '@react-native-community/netinfo';

export const netStatus = (callback) => {
  NetInfo.fetch().then((state) => {
    callback(state.isConnected);
  });
};

export async function getHeader(props) {
  // let Token = await Token;
  let header;
  header = {
    'Content-Type': 'application/json',
    // Authorization: `Bearer ${await _retrieveData('Token')}`,
  };
  return header;
}

export async function apiCall(url, method, body, success, failure) {
  let bodyParams = {};
  if (method === 'GET' || method === 'DELETE') {
    bodyParams = {
      method: method,
      headers: await getHeader(),
    };
  } else {
    bodyParams = {
      method: method,
      headers: await getHeader(),
      body: JSON.stringify(body),
    };
  }

  fetch(url, bodyParams)
    .then((response) => response.json())
    .then((dictSuccess) => {
      return success(dictSuccess);
    })
    .catch((error) => failure(error));
}

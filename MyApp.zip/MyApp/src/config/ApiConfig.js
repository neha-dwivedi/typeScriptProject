//Development URL
export const BASE_URL = 'https://jsonplaceholder.typicode.com/';

export const END_POINT = {
  //Endpoints
  LOGIN: BASE_URL + 'users',
  HOME_CATEGORY_LIST: BASE_URL + 'posts ',
  HOME_COMMENT_DETAIL: BASE_URL + 'comments ',
};

export const METHOD = {
  GET: 'GET',
  POST: 'POST',
  DELETE: 'DELETE',
  UPDATE: 'UPDATE',
};

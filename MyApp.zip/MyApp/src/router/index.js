/* eslint-disable no-unused-vars */
import React, {Component} from 'react';
import {Router, Scene} from 'react-native-router-flux';
import Home from './../screens/Home';
import Login from './../screens/Login';

class Route extends Component {
  //Design:- render design here..
  render() {
    return (
      <Router>
        <Scene
          key="root"
          hideNavBar="true"
          hideTabBar="true"
          panHandlers={null} // for disable swiping back in IOS
          duration={0} // to avoid sliding animation on IOS
          animationEnabled={true}>
          <Scene
            key="Login"
            hideNavBar="true"
            component={Login}
            initial={Login}
          />
          <Scene key="Home" component={Home} />
        </Scene>
      </Router>
    );
  }
}
export default Route;

import images from './images';
import colors from './colors';
import fonts from './fonts';
import strings from './strings';
import commonStyles from './commonStyles';
export {
    images,
    colors,
    fonts,
    strings,
    commonStyles
};

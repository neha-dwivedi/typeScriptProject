const fonts = {
    SweetSPBold: 'Sweet Sans Pro Bold',
    SweetSPItalic: 'Sweet Sans Pro Bold Italic',
    SweetSPExLight: 'Sweet Sans Pro Extra Light',
    SweetSPLightIalic: 'Sweet Sans Pro Extra Light Italic',
    SweetSPExThin: 'Sweet Sans Pro Extra Thin',

    SweetSPThinItalic: 'Sweet Sans Pro Extra Thin Italic',
    SweetSPHairLine: 'Sweet Sans Pro HairLine',
    SweetSPHLineItalic: 'Sweet Sans Pro HairLine Italic',
    SweetSPHeavy: 'Sweet Sans Pro Heavy',
    SweetSPHItalic: 'Sweet Sans Pro Heavy Italic',

    SweetSPItalic: 'Sweet Sans Pro Italic',
    SweetSPLight: 'Sweet Sans Pro Light',
    SweetSPLightItalic: 'Sweet Sans Pro Light Italic',
    SweetSPMedium: 'Sweet Sans Pro Medium',
    SweetSPMItalic: 'Sweet Sans Pro Medium Italic',

    SweetSPRegular: 'Sweet Sans Pro',
    SweetSPThin: 'Sweet Sans Pro Thin',
    SweetSPThinItalic: 'Sweet Sans Pro Thin Italic'
};
export default fonts;

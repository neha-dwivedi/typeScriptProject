export default AppImages = {
    "Oakwoodlogo": require('../assets/images/Logo.png'),
};

// import {StyleSheet} from 'react-native';
// import constantUtils from '../utils/constantUtils';
// import colors from './colors';
// import {moderateScale} from './styleConfig';
// import fonts from './fonts';

// export default StyleSheet.create({
//   container: {
//     flex: 1,
//   },
//   statusBar: {
//     height: constantUtils.STATUSBAR_HEIGHT,
//   },
//   inputTextFeildContanerStyle: {borderBottomColor: colors.darkGray},
//   textFieldStyle: {
//     fontSize: moderateScale(15),
//     fontFamily: fonts.SweetSPRegular,
//   },
// });

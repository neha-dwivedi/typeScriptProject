const colors = {
    "dashboardbackgroundcolor": '#0A1924',
    "homebackgroundcolor": '#3C748F',
    "whitetext": '#FFFFFF',
    "bluebackground": '#18A7E0',
    "switchbackgroundcolor": 'rgba(41, 54, 63, 0.5)',
    "switchactivebackgroundcolor": '#29363F',
    "switchfontcolor": 'rgba(255, 255, 255, 0.5)',
    "switchactivefontcolor": '#FFFFFF',
    "texttitlecolor": '#BDB9AD',
    "inprogresscolor": '#FEC107',
    "itemtextbox":'#BDB9AD',
    "notificationcolor":'#BD2929',
    "loadercolor":"#ffffff",
};
export default colors;
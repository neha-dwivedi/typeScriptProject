import {combineReducers} from 'redux';

import loginReducer from './Login';
import homeReducer from './Home';

const rootReducer = combineReducers({
  login: loginReducer,
  home: homeReducer,
  comments: homeReducer,
});

export default rootReducer;

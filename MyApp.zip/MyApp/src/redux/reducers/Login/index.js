import * as actionTypes from '../../actions/actionTypes';

const initialState = {
  login: [],
  forceUpdate: [],
};

const loginReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.FETCH_LOGIN_RESPONSE:
      return {
        ...state,
        login: action.payload,
      };
    default:
      return state;
  }
};

export default loginReducer;

import * as actionTypes from '../../actions/actionTypes';

const initialState = {
  home: [],
};

const homeReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.HOME_CATEGORY_LIST:
      return {
        ...state,
        home: action.payload,
      };
    case actionTypes.HOME_COMMENT_DETAIL:
      return {
        ...state,
        comments: action.payload,
      };
    default:
      return state;
  }
};

export default homeReducer;

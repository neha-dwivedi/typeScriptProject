import * as actionTypes from '../actionTypes';

export const fetchUserDetails = (data) => {
  return (dispatch) => {
    dispatch({
      type: actionTypes.HOME_CATEGORY_LIST,
      payload: data,
    });
  };
};

export const fetchUserComments = (data) => {
  return (dispatch) => {
    dispatch({
      type: actionTypes.HOME_COMMENT_DETAIL,
      payload: data,
    });
  };
};

import * as actionTypes from '../actionTypes';

export const fetchLoginAccounts = (data) => {
  return (dispatch) => {
    dispatch({
      type: actionTypes.FETCH_LOGIN_RESPONSE,
      payload: data,
    });
  };
};

export const Assets = {
  Oakwoodlogo: require('./images/Logo.png'),
};
